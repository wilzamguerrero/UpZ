import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ScrambleCycle } from './ScrambleText';

const LOADER_WORDS = [
  'ENVIAR',
  'RÁPIDO',
  'SIMPLE',
  'DISEÑO',
  'VELOZ',
  'NOTION',
  'LIMPIO',
  'DROPS',
  'SEGURO',
  'FLUIDO',
];

interface AppLoaderProps {
  visible: boolean;
}

export default function AppLoader({ visible }: AppLoaderProps) {
  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          key="app-loader"
          initial={{ opacity: 1 }}
          exit={{ opacity: 0, transition: { duration: 0.5, ease: [0.25, 0, 0.2, 1] } }}
          className="fixed inset-0 z-[9999] flex flex-col items-center justify-center select-none"
          style={{ backgroundColor: 'var(--loader-bg, #050505)' }}
        >
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35, ease: [0.25, 0, 0.2, 1] }}
            className="text-center"
          >
            {/* Big scramble cycling word */}
            <div
              className="font-mono font-bold leading-none tracking-tighter"
              style={{
                fontSize: 'clamp(3rem, 12vw, 7rem)',
                color: 'var(--accent, rgba(255,255,255,0.9))',
              }}
            >
              <ScrambleCycle
                words={LOADER_WORDS}
                interval={1600}
                duration={550}
              />
            </div>

            {/* Subtitle */}
            <div className="mt-5 text-[10px] font-mono text-white/20 uppercase tracking-[0.35em]">
              notion drop
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
